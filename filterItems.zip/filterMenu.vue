<!--完整组件-->
<template>
    <div class="filter_menu">
        <!--当前目录-->
        <div class="location_bar top_bar clearfix">
            <div class="title_bar">
                <slot name="title"></slot>
            </div>

            <div class="collapseBtn"  @click="toggleShow">
                <span>{{ isShowing?"收起":"展开" }}</span>
                <i class="el-icon-arrow-up" :class="{hover:isShowing, unhover:!isShowing}"></i>
            </div>
        </div>

        <!--筛选条件选项-->
        <div class="filter_box clearfix" v-show="isShowing">
            <filter-box :searchList="searchList" :hasOthers="hasOthers"
                :visible.sync="otherfilterDgVisible"
                @paramsChanged="paramsChanged" 
                @hasUnfilled="hasUnfilled">
            </filter-box>
        </div>

        <!--筛选条件-->
        <div class="filter_bar top_bar clearfix">
            <p class="filter_title">筛选条件: </p>
            <filter-list @filterListChange="filterListChange"></filter-list>
            <el-button type="primary" icon="el-icon-search" class="filterBtn" @click="makeParams()">查询</el-button>
        </div>

        <!--其它筛选条件-->
        <otherfilter-dialog :visible.sync="otherfilterDgVisible" 
            :searchList="otherSearchList"></otherfilter-dialog>

    </div>
</template>

<script>
    import filterBox from './filterBox'
    import otherfilterDialog from './otherfilterDialog'
    import filterList from './filterList'
    
    export default {
        name: "filter_menu",
        props:{
            searchList: Array,
            hasContrast: Boolean //是否有"同类对比条件"
        },
        data() {
            return {
                params: {}, //api参数
                filterLength: 0,
                unfilledList: [], //没有填的必选项集合
                isShowing: true,
                otherfilterDgVisible: false, //更多筛选条件隐藏显示
                otherSearchList: [""]
            }
        },
        computed:{
            hasOthers(){
                let tempList = this.searchList.filter(o=>{return o.inputtype==2}); //?
                return tempList.length>0? true: false;
            }
        },
        methods:{
            //向父级组件返回最终参数
            makeParams(){
                if(this.unfilledList.length>0){ //如果有必填项未填
                    this.$message({message: this.unfilledList.join(",") + '为必填项！', type: 'error'});
                }else{
                    this.$emit("paramsChanged", this.params); //向父组件传参
                }
            },
            //接收filterBox组件传值
            paramsChanged(data){
                //console.log(data);
                this.params = data;
            },
            //接收filterBox组件传值
            hasUnfilled(data){
                this.unfilledList = data;
            },
            //接收filterList组件传值
            filterListChange(legnth){
                this.filterLength = legnth;
            },
            //隐藏展示
            toggleShow(){
                this.isShowing = !this.isShowing;
            }
        },
        watch:{
            // level3Id:{ //如果第三级菜单id发生变化
            //     handler(newVal, oldVal){
            //         this.params.MenuID = parseInt(this.level3Id); //重新设置MenuID

            //         if(this.filterLength>0){
            //             this.params.MenuID = parseInt(this.level3Id); //重新设置MenuID
            //             this.makeParams(); //重新搜索
            //         }
            //     }
            // }
        },
        components:{
            filterBox, otherfilterDialog, filterList
        }

	}
</script>

<style lang="scss" type="text/css">
    .filter_menu{
        .top_bar{
            box-sizing: border-box;
            position: relative;
            padding: 8px 18px;
            background-color: #fff;
            //折叠按钮
            .collapseBtn{
                float: right;
                margin-top: 8px;
                cursor: pointer;

                i{
                    &.hover{
                        transform: rotate(180deg);
                        transition: all .5s;
                    }
                    &.unhover{
                        transform: rotate(360deg);
                        transition: all .5s;
                    }
                }
            }
        }
        //导航栏
        .location_bar{
            height: 50px;

            .title_bar{
                float: left;
                height: 34px;
                line-height: 34px;
            }
        }

        //筛选条件
        .filter_bar{
            border-top: 1px dashed #e0e0e1;
            border-bottom: 1px solid #e0e0e1;
            min-height: 60px;

            .filter_title{
                float: left;
                height: 32px;
                line-height: 32px;
            }
            ul{
                float: left;
                width: calc(100% - 180px);
            }
            .filterBtn{
                float: right;
            }
            
        }

    }

</style>